const score = {name:localStorage.name, score:localStorage.score, date:today};


module.exports = {
    score
}
